<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Arthgo
 */

get_header();

?>

	<main id="primary" class="site-main">
        <div class="blog_breadcrumb page_breadcrumb">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="breadcrumb_content">
                            <div class="page_name">Blog Post</div>
                            <h1 class="title text-white"><?php echo get_the_title(); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div class="blog_single_wrpper single_page_bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="blog_single_content">
                            
                            <?php
                                while ( have_posts() ) :
                                    the_post();
                                    echo the_content();
                                endwhile; // End of the loop.
                                wp_reset_postdata(  );

                            ?>
                        </div>
                    </div>
					<div class="col-lg-4">
                        <div class="blog_single_sidebar ps-lg-5">
                            <!-- Search Bar -->
                            <div class="sidebar_item search_bar">
                                <p class="title text-white mb-2">Search</p>
                                <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                                    <input type="search" class="search-field" placeholder="<?php echo esc_attr_x('Search...', 'placeholder', 'textdomain'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
                                    <button type="submit" class="search-submit"><i class="fas fa-search"></i></button>
                                </form>
                            </div>

                            <!-- Post Thumbnail -->
                            <div class="sidebar_item post_thumbnail">
                                <?php
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('large'); // You can change 'thumbnail' to other sizes like 'medium', 'large', etc.
                                } else {
                                    echo '<img src="' . esc_url(get_template_directory_uri() . '/images/default-thumbnail.jpg') . '" alt="Default Thumbnail">'; // Add a default thumbnail if no featured image is set
                                }
                                ?>
                            </div>

                            <!-- Categories -->
                            <div class="sidebar_item">
                                <h3 class="title">Categories</h3>
                                <?php
                                $categories = get_categories();

                                if ($categories) {
                                    echo '<div class="category_list">';
                                    foreach ($categories as $category) {
                                        $category_link = get_category_link($category->term_id);
                                        echo '<a href="' . esc_url($category_link) . '">' . esc_html($category->name) . '</a>';
                                    }
                                    echo '</div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</main><!-- #main -->

<?php

get_footer();
