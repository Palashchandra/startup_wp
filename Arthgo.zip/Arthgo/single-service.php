<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Arthgo
 */

get_header();

?>

	<main id="primary" class="site-main">
        <div class="services_breadcrumb page_breadcrumb">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="breadcrumb_content text-center">
                            <div class="breadcrumb_menu d-inline-flex flex-wrap align-items-center justify-content-center">
                                <div><a class="text-white menu_item" href="<?php echo home_url(); ?>">Home</a></div>
                                <div class="text-white separator"><i class="fas fa-chevron-right"></i></div>
                                <div><a class="text-white menu_item" href="<?php echo home_url(); ?>/services/">Services</a></div>
                                <div class="text-white separator"><i class="fas fa-chevron-right"></i></div>
                                <div class="text-white menu_item current">Service Details</div>
                            </div>
                            <h2 class="title mb-0 mt-4 text-white"><?php echo get_the_title(); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div class="services_single_wrpper single_page_bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="services_single_content">
                            <?php
                                if(!empty(get_the_post_thumbnail_url())){
                                    ?>
                                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#" class="img-fluid services_thumbnail">
                                    <?php
                                }
                            ?>
                            <?php
                                while ( have_posts() ) :
                                    the_post();

                                    echo the_content();
                                    
                                endwhile; // End of the loop.
                                wp_reset_postdata(  );

                            ?>
                        </div>
                        
                    </div>
                </div>
            </div>
		</div>
	</main><!-- #main -->

<?php

get_footer();
