<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Arthgo
 */

?>

<div class="col-sm-6 col-lg-4">
	<div class="blog_post_item">
		<?php if(!empty(get_the_post_thumbnail_url())) : ?>
		<a href="<?php echo get_the_permalink(); ?>" class="post_thumb">
			<img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="#" class="img-fl">
		</a>
		<?php endif; ?>

		<div class="post_content">
			<h4 class="title"><a href="<?php echo get_the_permalink(); ?>"><?php echo the_title(); ?></a></h4>
			<p class="description"><?php echo wp_trim_words(get_the_excerpt(), 10, '....') ; ?></p>
			<div class="post_meta d-flex align-items-center justify-content-between">
				<a href="<?php echo get_the_permalink(); ?>" class="read_more">Read More <i class="fas fa-arrow-right"></i></a>
				<p class="post-date">
					<?php echo get_the_date('j M, Y'); ?>
				</p>
			</div>
		</div>
	</div>
</div>
