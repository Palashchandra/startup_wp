<?php 
/**
 * template to display single page content 
 */

?>
<div class="blog_single_info">
    <div class="media_blog_content">
        <?php
            // Check if we are on a single post page
            if (is_single()) {
                $categories = get_the_category(); // Get categories assigned to the post
                $blog_page_id = get_option('page_for_posts'); // Get the ID of the blog page
                $home_page_id = get_option('page_on_front'); // Get the ID of the front page

                // Get the titles of the home page and blog page
                $home_page_title = get_the_title($home_page_id);
                $blog_page_title = get_the_title($blog_page_id);

                echo '<div class="breadcrumb mb-2 mb-lg-3">';

                // Home link
                echo '<a href="' . esc_url(home_url('/')) . '">' . esc_html($home_page_title) . '</a> ';

                echo '<div class="separator"><i class="fas fa-chevron-right"></i></div>';

                // Blog page link
                echo '<a href="' . esc_url(get_permalink($blog_page_id)) . '">Blog</a> ';

                echo '<div class="separator"><i class="fas fa-chevron-right"></i></div>';

                // Category link (if post is assigned to a category)
                if ($categories) {
                    $category = $categories[0]; // Assuming we use only one category per post
                    echo '<a class="current_page" href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a> ';
                }

                echo '</div>'; // Close breadcrumb container 
            }
        ?>
        <h2 class="title"><?php echo the_title(); ?></h2>
        <?php if(has_post_thumbnail( )) {  ?>
        <div class="single-page-media">
           <?php the_post_thumbnail(); ?>
        </div>
        <?php } ?>
       
        <?php the_content();
        ?>
    </div>
</div>
                      
    <!-- End medical blog list area -->

 