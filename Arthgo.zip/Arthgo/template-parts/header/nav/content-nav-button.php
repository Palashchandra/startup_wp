<?php
$header_btn_text = Arthgo_options('header_btn_text');
$header_btn_url = Arthgo_options('header_btn_url');
$header_btn_text = is_string($header_btn_text) ? esc_html($header_btn_text) : '';
$header_btn_url  = esc_url($header_btn_url);

if ( ! empty($header_btn_text) ) : ?>
    <a class="cre_btn_wrapper contact_btn" href="<?php echo $header_btn_url; ?>">
        <?php echo $header_btn_text; ?> 
        <div class="icon">
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M11.0044 3.414L2.3974 12.021L0.983398 10.607L9.5894 2H2.0044V0H13.0044V11H11.0044V3.414Z" fill="#0066FF"/>
            </svg>
        </div>
    </a>
<?php endif; ?>