<?php
$offcanvus_background_url = Arthgo_IMAGES.'/offcanvus_bg.png';
?>
<nav class="navbar navbar-expand-xl menu_one p-0">
    <div class="container custom_container position-relative">
        <div class="header_part_wrapper d-flex align-items-center justify-content-between">
            <div class="navbar_logo">
                <?php Arthgo_logo(); ?>
            </div>
            <div class="header_right_part d-flex align-items-center">
                <div class="header_menu_inner d-none d-xl-block" id="navbarSupportedContent">
                    <?php 
                        wp_nav_menu( array(
                            'menu_class' => 'navbar-nav menu',
                            'container'  => '',
                            'theme_location' => 'primary',
                            'walker'         => new Arthgo_Navwalker(),
                            'fallback_cb'     => false,
                        ) ); 
                    ?>
                </div>
            </div>
            <div class="header_left_content d-flex align-items-center">
                <div class="d-none d-xl-block">
                    <?php get_template_part( 'template-parts/header/nav/content-nav', 'button') ?>
                </div>
                <a class="max_offcanvas_icon d-xl-none btn btn-primary" data-bs-toggle="offcanvas" href="#max_offcanvas" role="button" aria-controls="max_offcanvas">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M21 11H7" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M21 6H3" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M21 16H3" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M21 21H7" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                </a>
            </div>
        </div>
    </div>
</nav>

<div class="offcanvas offcanvas-start" tabindex="-1" id="max_offcanvas" aria-labelledby="offcanvasExampleLabel" data-bg-img="<?php echo esc_url($offcanvus_background_url); ?>">
    <div class="offcanvas-header d-xl-none p-0">
        <?php Arthgo_logo(); ?>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <?php 
        wp_nav_menu( array(
            'menu_class' => 'navbar-nav menu',
            'container'  => '',
            'theme_location' => 'primary',
            'walker'         => new Arthgo_Navwalker(),
            'fallback_cb'     => false,
        ) );
    ?>
    <?php get_template_part( 'template-parts/header/nav/content-nav', 'button') ?>
</div>