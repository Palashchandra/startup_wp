jQuery(function () {
	'use strict';
	//*============ background image js ==============*/

  
	$('[data-bg-img]').each(function () {
		var bg = $(this).data('bg-img');
		$(this).css({
			background: 'no-repeat center 0/cover url(' + bg + ')',
		});
	});

	//* Navbar Fixed
	// function navbarFixed() {
	// 	if ($('.sticky_nav').length) {
	// 		$(window).scroll(function () {
	// 			var scroll = $(window).scrollTop();
	// 			if (scroll) {
	// 				$('.sticky_nav').addClass('navbar_fixed');
	// 			} else {
	// 				$('.sticky_nav').removeClass('navbar_fixed');
	// 			}
	// 		});
	// 	}
	// }

	// navbarFixed();

	$(".navbar-toggler").on("click", function(){
		$(".navbar.fixed-top").toggleClass("menu_collaps");
	});
	$(".accordion-button").on("click", function () {
      var $item = $(this).closest(".accordion-item");
      
      // If it's already active, remove the class
      if ($item.hasClass("accordion-item-active")) {
          $item.removeClass("accordion-item-active");
      } else {
          // Otherwise, remove from all and add to the clicked one
          $(".accordion-item").removeClass("accordion-item-active");
          $item.addClass("accordion-item-active");
      }
  });
   // $('.accordion-item').on('click', function () {   

    //services slider js
    var swiper = new Swiper(".popup_wrapper_box", {
        loop: true,
        spaceBetween: 30,
        autoplay: false,
        navigation: {
            nextEl: '.popup_next',
            prevEl: '.popup_prev',
        },
        pagination: {
            el: ".cre_popup_pag",
            clickable: true
        },
        breakpoints: {
            320: {
              slidesPerView: 1
            },
            576: {
              slidesPerView: 2
            },
            768: {
              slidesPerView: 3,
            },
            1200: {
              slidesPerView: 3,
            }
        }
    });

    //image slider js
    var swiper = new Swiper(".testimonial_slider", {
        loop: true,
        spaceBetween: 30,
        autoplay: false,
        slidesPerView: 1,
        navigation: {
            nextEl: '.testimonial_next',
            prevEl: '.testimonial_prev',
        },
    });

    $('.popup-video').magnificPopup({
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
		    fixedContentPos: false
    });

    function convertTabsToAccordion() {
    $('.elementor-widget-rising-master').each(function () {
      const container = $(this);

      // Skip if already converted
      if ($(window).width() < 991 && !container.hasClass('accordion-initialized')) {
        container.addClass('accordion-initialized');

        // Get widget ID from the first tab button's ID
        const firstTab = container.find('[id^="pills-tab-"]').first();
        if (!firstTab.length) return;

        const idParts = firstTab.attr('id').split('pills-tab-');
        const widgetId = idParts[1] || 'default';

        const tabButtons = container.find('.nav-pills .tab_menu_item');
        const tabContents = container.find('.tab-content .tab-pane');

        let accordionHTML = `<div class="accordion" id="accordion-${widgetId}">`;

        tabButtons.each(function (index) {
          const $btn = $(this);
          const targetId = $btn.data('bs-target').replace('#', '');
          const title = $.trim($btn.text());
          const icon = $btn.find('img').attr('src') || '';
          const isActive = $btn.hasClass('active');
          const contentHTML = $('#' + targetId).html();

          const collapseId = `collapse-${widgetId}-${index}`;

          accordionHTML += `
            <div class="accordion-item">
              <h2 class="accordion-header" id="heading-${collapseId}">
                <button class="accordion-button ${isActive ? '' : 'collapsed'}" type="button"
                  data-bs-toggle="collapse" data-bs-target="#${collapseId}"
                  aria-expanded="${isActive}" aria-controls="${collapseId}">
                  ${icon ? `<img src="${icon}" class="me-2" style="max-height:20px;">` : ''}
                  ${title}
                </button>
              </h2>
              <div id="${collapseId}" class="accordion-collapse collapse ${isActive ? 'show' : ''}"
                aria-labelledby="heading-${collapseId}" data-bs-parent="#accordion-${widgetId}">
                <div class="accordion-body">
                  ${contentHTML}
                </div>
              </div>
            </div>`;
        });

        accordionHTML += '</div>';

        // Replace the tabs with the new accordion
        container.find('.nav-pills').remove();
        container.find('.tab-content').replaceWith(accordionHTML);
      }
    });
  }

  // Initial run
  convertTabsToAccordion();

  // Optional: re-run on resize
  $(window).on('resize', function () {
    if ($(window).width() < 768) {
      convertTabsToAccordion();
    }
  });


});

