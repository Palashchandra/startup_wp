<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Arthgo
 */

get_header();
// Check if it's a category archive
if (is_category()) {
    $archive_title = single_cat_title('', false);
	$page_name = 'Category';
} elseif (is_tag()) { // Check if it's a tag archive
    $archive_title = single_tag_title('', false);
	$page_name = 'Tag';
} elseif (is_author()) { // Check if it's an author archive
    $archive_title = get_the_author();
} elseif (is_date()) { // Check if it's a date-based archive
    $archive_title = get_the_date('F Y');
} elseif (is_search()) { // Check if it's a search results page
    $archive_title = 'Search Results';
} elseif (is_post_type_archive()) { // Check if it's a custom post type archive
    $archive_title = post_type_archive_title('', false);
} else {
    $archive_title = 'Archives';
}
$blog_sidebar = Arthgo_options('Arthgo_blog_setting');

?>

	<main id="primary" class="site-main explore_blog ">
        <div class="container cre_all_blog_wrapper">
			 <section class="archive-header text-center mb-5">
				<h2 class="archive-title"><?php echo $page_name; ?> Name: <?php echo esc_html($archive_title); ?></h2>
			</section>
            <div class="row">
                <?php
                if ( have_posts() ) :

                    /* Start the Loop */
                    while ( have_posts() ) :
                        the_post();

                        /*
                            * Include the Post-Type-specific template for the content.
                            * If you want to override this in a child theme, then include a file
                            * called content-___.php (where ___ is the Post Type name) and that will be used instead.
                            */
                        get_template_part( 'template-parts/content');

                    endwhile;

                endif;
				
                ?>
            </div>
        </div>
	</main><!-- #main -->

<?php

get_footer();
