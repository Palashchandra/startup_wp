<?php

Redux::set_section('Arthgo', array(
	'title'     => esc_html__( 'Blog', 'Arthgo' ),
	'id'        => 'blog_page',
	'icon'      => 'dashicons dashicons-admin-post',
));



