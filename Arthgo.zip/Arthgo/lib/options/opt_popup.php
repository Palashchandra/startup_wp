<?php
    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Cookies Popup', 'Arthgo' ),
        'id'                => 'cookies_popup',
        'customizer_width'  => '400px',
        'icon'              => 'el el-home'
    ));

    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Header Content', 'Arthgo' ),
        'id'                => 'cookies_popup_content',
        'subsection'        => true,
        'fields'            => array(
            array(
                'id' => 'popup_title',
                'type' => 'text',
                'title' => __( 'Popup Title' , 'Arthgo' ),
                'default'   => __( 'Cookies Settings', 'Arthgo' ),
            ),
            array(
				'title'     => esc_html__('Popup Description', 'Arthgo'),
				'id'        => 'popup_description',
				'type'      => 'editor',
				'default'   => 'Buy More, Save More with our exclusive Instructor Led Training Prepay Packages!',
				'args'    => array(
					'wpautop'       => true,
					'media_buttons' => false,
					'textarea_rows' => 10,
					'teeny'         => false,
				)
			),
            array(
                'id' => 'list_title',
                'type' => 'text',
                'title' => __( 'List Title' , 'Arthgo' ),
                'default'   => __( 'Functionality Allowed', 'Arthgo' ),
            ),
            
            array(
				'title'     => esc_html__('Popup functionality', 'Arthgo'),
				'id'        => 'popup_functionality',
				'type'      => 'editor',
				'default'   => 'Buy More, Save More with our exclusive Instructor Led Training Prepay Packages!',
				'args'    => array(
					'wpautop'       => true,
					'media_buttons' => false,
					'textarea_rows' => 10,
					'teeny'         => false,
				)
			),

            array(
				'id'=>'icon_select_field',
				'type' => 'icon_select', 
				//'required' => array('switch-fold','equals','0'),	
				'title' => __('Icon Select', 'Arthgo'),
				'subtitle'	=> __('Select an icon.', 'Arthgo'),
				'default' 	=> 'fa-brands fa-facebook-f',
			),
        )
    ));
?>