<?php

Redux::set_section('Arthgo', array(
    'title'            => esc_html__( 'Banner Setting', 'Arthgo' ),
    'id'               => 'headers_typo_opt',
    'icon'             => 'el el-picture',
));

// Page Banner 
Redux::set_section('Arthgo', array(
    'title'            => esc_html__( 'Page Banner', 'Arthgo' ),
    'id'               => 'Banner',
    'icon'             => 'el el-cog',
    'subsection' => true,
    'fields'           => array(
        array(
            'id'       => 'Arthgo_page_banner_toggle',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Page Banner', 'Arthgo'),
            'subtitle' => esc_html__('Show Hide Page Banner Globally ', 'Arthgo'),
            'options' => array(
                'show' => esc_html__('Show Banner', 'Arthgo'), 
                'hide' => esc_html__('Hide Banner', 'Arthgo'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'Arthgo_page_banner_breadcrumb',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Page Breadcrumb', 'Arthgo'),
            'options' => array(
                'show' => esc_html__('Show', 'Arthgo'), 
                'hide' => esc_html__('Hide', 'Arthgo'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'Arthgo_page_banner_title',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Page Title', 'Arthgo'),
            'options' => array(
                'show' => esc_html__('Show', 'Arthgo'), 
                'hide' => esc_html__('Hide', 'Arthgo'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'Arthgo_page_banner_upload',
            'type'     => 'media', 
            'url'      => true,
            'title'    => __('Upload Banner', 'Arthgo'),
            'default'  => array(
                'url'=> Arthgo_IMAGES.'/blog/banner/blog_details_img.jpg',
            ),
            'url'      => false

        ),
        array(
            'id'        => 'Arthgo_page_banner_overly',
            'type'      => 'color_rgba',
            'title'     => 'Banner Overly Color',
            'mode'      => 'background',
            'output'    => array( '.blog_breadcrumbs_area_two.page-banner .overlay_bg' ),
            'default'   => array(
                'color'     => '#000',
                'alpha'     => .5
            ),                        
        ),
      )
));


// Blog Banner 

Redux::set_section('Arthgo', array(
    'title'            => esc_html__( 'Blog Banner', 'Arthgo' ),
    'id'               => 'blog_banner',
    'icon'             => 'el el-cog',
    'subsection' => true,
    'fields'           => array(
        array(
            'id'       => 'Arthgo_blog_banner_title',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Blog Title', 'Arthgo'),
            'options' => array(
                'show' => esc_html__('Show', 'Arthgo'), 
                'hide' => esc_html__('Hide', 'Arthgo'), 
            ), 
            'default' => 'show'
        ),
        array( 
            'title'    => esc_html__('Blog title', 'Arthgo'),
            'id' => 'Arthgo_blog_title',
            'type' => 'text',
            'required' => array('Arthgo_blog_banner_title', '=' , 'show')
        ),
        array( 
            'title'    => esc_html__('Blog Description', 'Arthgo'),
            'id' => 'Arthgo_blog_description',
            'type' => 'textarea',
        ),
      )
));



