<?php 
Redux::set_section('Arthgo', array(
    'title'            => esc_html__( '404 Banner', 'Arthgo' ),
    'id'               => 'Arthgo_404_banner',
    'icon'             => 'el el-cog',
    'subsection' => true,
    'fields'           => array(
        array(
            'id'       => 'Arthgo_404_banner_toggle',
            'type'     => 'button_set',
            'title'    => esc_html__('Show 404  Banner', 'Arthgo'),
            'options' => array(
                'show' => esc_html__('Show Banner', 'Arthgo'), 
                'hide' => esc_html__('Hide Banner', 'Arthgo'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'Arthgo_404_title',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Title', 'Arthgo'),
            'options' => array(
                'show' => esc_html__('Show', 'Arthgo'), 
                'hide' => esc_html__('Hide', 'Arthgo'), 
            ), 
            'default' => 'show'
        ),
        array(
            'title'    => esc_html__('404 Banner Titile', 'Arthgo'),
            'type' => 'text',
            'id'       => 'Arthgo_404_banner_title',
            'placeholder' => esc_html__( '404 Banner Titile', 'Arthgo'),
            'required'    => array('Arthgo_404_title', '=', 'show')
        ),
        array(
            'id'       => 'Arthgo_404_banner_breadcrumb',
            'type'     => 'button_set',
            'title'    => esc_html__('Show Breadcrumb', 'Arthgo'),
            'options' => array(
                'show' => esc_html__('Show', 'Arthgo'), 
                'hide' => esc_html__('Hide', 'Arthgo'), 
            ), 
            'default' => 'show'
        ),
        array(
            'id'       => 'Arthgo_404_banner_upload',
            'type'     => 'media', 
            'url'      => true,
            'title'    => __('Upload Banner', 'Arthgo'),
            'default'  => array(
                'url'=> Arthgo_IMAGES.'/blog/banner/blog_details_img.jpg',
            ),
            'url'      => false

        ),
        array(
            'id'        => 'Arthgos_404_banner_overly',
            'type'      => 'color_rgba',
            'title'     => 'Banner Overly Color',
            'mode'      => 'background',
            'output'    => array( '.blog_breadcrumbs_area_two.banner-404 .overlay_bg' ),
            'default'   => array(
                'color'     => '#000',
                'alpha'     => .5
            ),                        
        ),
      )
));