<?php
// Header Section
Redux::set_section( 'Arthgo', array(
    'title'            => esc_html__( 'Header', 'Arthgo' ),
    'id'               => 'Arthgo_header_sec',
    'customizer_width' => '400px',
    'icon'             => 'el el-arrow-up',
));


// Logo
Redux::set_section( 'Arthgo', array(
    'title'            => esc_html__( 'Logo', 'Arthgo' ),
    'id'               => 'Arthgo_logo_opt',
    'subsection'       => true,
    'icon'             => '',
    'fields'           => array(
        array(
            'title'     => esc_html__( 'Upload logo', 'Arthgo' ),
            'subtitle'  => esc_html__( 'Upload here a image file for your logo', 'Arthgo' ),
            'id'        => 'Arthgo_logo',
            'type'      => 'media',
            'default'   => array(
                'url'   => Arthgo_IMAGES.'/default_logo/logo.png'
            )
        ),

        array(
            'title'     => esc_html__( 'Sticky header logo', 'Arthgo' ),
            'id'        => 'Arthgo_sticky_logo',
            'type'      => 'media',
            'default'   => array(
                'url'   => Arthgo_IMAGES.'/default_logo/logo_sticky.png'
            )
        ),

        array(
            'title'     => esc_html__( 'Retina Logo', 'Arthgo' ),
            'subtitle'  => esc_html__( 'The retina logo should be double (2x) of your original logo', 'Arthgo' ),
            'id'        => 'Arthgo_retina_logo',
            'type'      => 'media',
        ),

        array(
            'title'     => esc_html__( 'Retina Sticky Logo', 'Arthgo' ),
            'subtitle'  => esc_html__( 'The retina logo should be double (2x) of your original logo', 'Arthgo' ),
            'id'        => 'Arthgo_retina_sticky_logo',
            'type'      => 'media',
        ),

        array(
            'title'     => esc_html__( 'Logo dimensions', 'Arthgo' ),
            'subtitle'  => esc_html__( 'Set a custom height width for your upload logo.', 'Arthgo' ),
            'id'        => 'logo_dimensions',
            'type'      => 'dimensions',
            'units'     => array( 'em','px','%' ),
            'output'    => '.logo_info .navbar-brand img'
        ),

        array(
            'title'     => esc_html__( 'Padding', 'Arthgo' ),
            'subtitle'  => esc_html__( 'Padding around the logo. Input the padding as clockwise (Top Right Bottom Left)', 'Arthgo' ),
            'id'        => 'logo_padding',
            'type'      => 'spacing',
            'output'    => array( '.logo_info .navbar-brand img' ),
            'mode'      => 'padding',
            'units'     => array( 'em', 'px', '%' ),      // You can specify a unit value. Possible: px, em, %
            'units_extended' => 'true',
        ),
        
    )
) );

// Logo
Redux::set_section( 'Arthgo', array(
    'title'            => esc_html__( 'Header Button', 'Arthgo' ),
    'id'               => 'Arthgo_btn_opt',
    'subsection'       => true,
    'icon'             => '',
    'fields'           => array(
        array(
            'title'     => esc_html__( 'Button Text', 'Arthgo' ),
            'id'        => 'header_btn_text',
            'type'      => 'text',
            'default'   => esc_html__( 'Create Account', 'Arthgo' ),
        ),
        array(
            'title'     => esc_html__( 'Button URL', 'Arthgo' ),
            'id'        => 'header_btn_url',
            'type'      => 'text',
            'default'   => esc_url( home_url( '/' ) ),
        ),
    )
) );