<?php
    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Header Top', 'Arthgo' ),
        'id'                => 'sub_header',
        'customizer_width'  => '400px',
        'icon'              => 'el el-home'
    ));

    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Header Content', 'Arthgo' ),
        'id'                => 'sub_header_meta',
        'subsection'        => true,
        'fields'            => array(
            array(
                'id'         => 'social_icons_repeater',
                'type'       => 'repeater',
                'title'      => __( 'Social Info', 'Arthgo' ),
                'subtitle'   => __( '', 'Arthgo' ),
                'desc'       => __( '', 'Arthgo' ),
                'fields'     => array(
                    array(
                        'title'     => esc_html__('Icon', 'Arthgo'),
                        'id'          => 'social_icon_1',
                        'type'        => 'text',
                        'placeholder' => __( 'Social Icon', 'Arthgo' ),
                    ),
                    array(
                        'title'     => esc_html__('Link', 'Arthgo'),
                        'id'          => 'header_social_link_1',
                        'type'        => 'text',
                        'placeholder' => __( 'Social Link', 'Arthgo' ),
                    ),
                    array(
                        'title'     => esc_html__('Icon', 'Arthgo'),
                        'id'          => 'social_icon_2',
                        'type'        => 'text',
                        'placeholder' => __( 'Social Icon', 'Arthgo' ),
                    ),
                    array(
                        'title'     => esc_html__('Link', 'Arthgo'),
                        'id'          => 'header_social_link_2',
                        'type'        => 'text',
                        'placeholder' => __( 'Social Link', 'Arthgo' ),
                    ),
                    array(
                        'title'     => esc_html__('Icon', 'Arthgo'),
                        'id'          => 'social_icon_3',
                        'type'        => 'text',
                        'placeholder' => __( 'Social Icon', 'Arthgo' ),
                    ),
                    array(
                        'title'     => esc_html__('Link', 'Arthgo'),
                        'id'          => 'header_social_link_3',
                        'type'        => 'text',
                        'placeholder' => __( 'Social Link', 'Arthgo' ),
                    ),
                    array(
                        'title'     => esc_html__('Icon', 'Arthgo'),
                        'id'          => 'social_icon_4',
                        'type'        => 'text',
                        'placeholder' => __( 'Social Icon', 'Arthgo' ),
                    ),
                    array(
                        'title'     => esc_html__('Link', 'Arthgo'),
                        'id'          => 'header_social_link_4',
                        'type'        => 'text',
                        'placeholder' => __( 'Social Link', 'Arthgo' ),
                    ),
                )
            ),
			array(
				'title'     => esc_html__('Header Top Text', 'Arthgo'),
				'id'        => 'h_top_txt',
				'type'      => 'editor',
				'default'   => 'Buy More, Save More with our exclusive Instructor Led Training Prepay Packages!',
				'args'    => array(
					'wpautop'       => true,
					'media_buttons' => false,
					'textarea_rows' => 10,
					'teeny'         => false,
				)
			),
        )
    ));




?>