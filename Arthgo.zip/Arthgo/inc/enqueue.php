<?php 
/**
 * Enqueue scripts and styles.
 */
function Arthgo_scripts() {
	wp_enqueue_style( 'Arthgo-style', get_stylesheet_uri(), array(), Arthgo_VERSION );
	wp_enqueue_style( 'bootstarp-css', Arthgo_CSS.'/bootstarp.css', array( 'Arthgo-style' ), Arthgo_VERSION );
	wp_enqueue_style( 'fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array( 'Arthgo-style' ), Arthgo_VERSION );
	wp_enqueue_style( 'magnific-popup', Arthgo_CSS.'/magnific-popup.css', array( 'Arthgo-style' ), Arthgo_VERSION );
	wp_enqueue_style( 'Arthgo-animate', Arthgo_CSS.'/animate.css', array( 'Arthgo-style' ), Arthgo_VERSION );
	wp_enqueue_style( 'swiper', Arthgo_vendor_CSS.'/swiper/swiper-bundle.min.css', array( 'Arthgo-style' ), Arthgo_VERSION );
	wp_enqueue_style( 'Arthgo-style-main', get_theme_file_uri('/assets/css/style.css'), array(), Arthgo_VERSION );


	//  Enqueue script   
	wp_enqueue_script( 'bootstarp-js', Arthgo_JS. '/bootstarp.js', array('jquery'), Arthgo_VERSION, true );
	wp_enqueue_script( 'mediaelement-and-player', Arthgo_JS. '/mediaelement-and-player.min.js', array('jquery'), Arthgo_VERSION, true );
	wp_enqueue_script( 'magnific-popup', Arthgo_JS. '/jquery.magnific-popup.js', array('jquery'), Arthgo_VERSION, true );
	wp_enqueue_script( 'Arthgo-wow', Arthgo_JS . '/wow.min.js', array(), Arthgo_VERSION, true );
	wp_enqueue_script( 'swiper-theme', Arthgo_vendor_JS . '/swiper/swiper-bundle.min.js', array(), Arthgo_VERSION, true );
	wp_enqueue_script( 'Arthgo-main', Arthgo_JS . '/main.js', array('jquery'), Arthgo_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script('comment-reply');
	}
		
}
add_action('wp_enqueue_scripts', 'Arthgo_scripts');