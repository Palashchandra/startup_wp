<?php 

/**
 * Custom template tags for this theme.
 */
require Arthgo_THEMEROOT_DIR . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require Arthgo_THEMEROOT_DIR . '/inc/template-functions.php';

/**
 * Arthgo helper 
 */
require Arthgo_THEMEROOT_DIR . '/inc/helper.php';

/**
 * Arthgo comment area
*/
require Arthgo_THEMEROOT_DIR.'/inc/classes/comment_walker.php';

/**
 * Arthgo nav walker
*/
require Arthgo_THEMEROOT_DIR.'/inc/classes/main-nav-walker.php';

/**
 * Customizer additions.
 */
require Arthgo_THEMEROOT_DIR . '/inc/customizer.php';

/**
 * Arthgo Enqueue 
 */

require Arthgo_THEMEROOT_DIR . '/inc/enqueue.php';

/**
 * Arthgo breadcrumbs
 */

require Arthgo_THEMEROOT_DIR . '/inc/breadcrumbs.php';

/**
 * Arthgo Tgm
 */
require Arthgo_THEMEROOT_DIR . '/inc/plugin_activation.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require Arthgo_THEMEROOT_DIR . '/inc/jetpack.php';
}
